import { useEffect, useRef, useState } from 'react';
import { TrendingUp, LineChart, Sparkles } from 'lucide-react';

const About = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const features = [
    {
      icon: TrendingUp,
      title: 'AI-Powered Trading',
      description: 'Real-time market analysis and intelligent execution',
    },
    {
      icon: LineChart,
      title: 'Strategic Growth',
      description: 'Data-driven investment strategies for optimal returns',
    },
    {
      icon: Sparkles,
      title: 'Exclusive Access',
      description: 'Premium opportunities in transformative ventures',
    },
  ];

  return (
    <section
      ref={sectionRef}
      id="about"
      className="relative py-24 sm:py-32 overflow-hidden"
    >
      {/* Background Elements */}
      <div className="absolute inset-0 grid-bg opacity-30" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-neon-green/5 rounded-full blur-[150px]" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <div
            className={`transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'
            }`}
          >
            {/* Section Label */}
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass mb-6">
              <span className="w-2 h-2 rounded-full bg-neon-green animate-pulse" />
              <span className="text-xs font-medium text-neon-green tracking-wider uppercase">
                About The Program
              </span>
            </div>

            {/* Heading */}
            <h2 className="text-4xl sm:text-5xl font-bold text-white mb-6 leading-tight">
              Pioneering the{' '}
              <span className="gradient-text">Future of Intelligent Investment</span>
            </h2>

            {/* Description */}
            <p className="text-lg text-gray-400 leading-relaxed mb-6">
              Quantum Program is a private advanced initiative combining quantum artificial 
              intelligence and strategic innovation to redefine financial growth. Designed 
              for individuals who believe in progress and technological evolution, we are 
              building a smarter path toward financial independence.
            </p>

            <p className="text-gray-500 leading-relaxed mb-6">
              As part of our mission to empower a select community of forward-thinking 
              supporters, we have introduced an exclusive Quantum Investment Program. By 
              leveraging real-time market data, AI precision, and advanced trading strategies, 
              the system intelligently operates across high-growth assets such as Tesla, 
              SpaceX, and other transformative ventures.
            </p>

            <p className="text-gray-500 leading-relaxed mb-8">
              Our goal is simple: to harness cutting-edge technology to create exceptional 
              opportunities and accelerate financial freedom. Join us in shaping a future 
              where intelligent systems work seamlessly to unlock your greatest potential.
            </p>

            {/* Feature Tags */}
            <div className="flex flex-wrap gap-3">
              {['AI Trading', 'Tesla & SpaceX', 'Quantum Analytics', 'Financial Freedom'].map((tag, index) => (
                <span
                  key={index}
                  className="px-4 py-2 rounded-lg glass text-sm text-neon-green border border-neon-green/20 hover:border-neon-green/50 transition-colors cursor-default"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>

          {/* Right Content - Feature Cards */}
          <div
            className={`space-y-6 transition-all duration-700 delay-200 ${
              isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'
            }`}
          >
            {features.map((feature, index) => (
              <div
                key={index}
                className="group p-6 rounded-2xl glass hover-lift glow-border cursor-default"
                style={{ transitionDelay: `${index * 100}ms` }}
              >
                <div className="flex items-start gap-5">
                  <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-neon-green/10 flex items-center justify-center group-hover:bg-neon-green/20 transition-colors">
                    <feature.icon className="w-6 h-6 text-neon-green" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-white mb-2 group-hover:text-neon-green transition-colors">
                      {feature.title}
                    </h3>
                    <p className="text-gray-400">
                      {feature.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}

            {/* Decorative Element */}
            <div className="relative h-32 rounded-2xl overflow-hidden glass">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="flex items-center gap-4">
                  <div className="w-3 h-3 rounded-full bg-neon-green animate-pulse" />
                  <div className="w-3 h-3 rounded-full bg-neon-green animate-pulse" style={{ animationDelay: '0.2s' }} />
                  <div className="w-3 h-3 rounded-full bg-neon-green animate-pulse" style={{ animationDelay: '0.4s' }} />
                </div>
              </div>
              <div className="absolute inset-0 bg-gradient-to-r from-neon-green/5 via-transparent to-neon-green/5" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
