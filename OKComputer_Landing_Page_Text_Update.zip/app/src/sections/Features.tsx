import { useEffect, useRef, useState } from 'react';
import { Shield, Brain, Atom, Lock } from 'lucide-react';

const Features = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const features = [
    {
      icon: Shield,
      title: 'Secure Access',
      description: 'Military-grade encryption and multi-factor authentication protect your data and access to the Quantum Program ecosystem.',
      gradient: 'from-emerald-500/20 to-green-500/20',
    },
    {
      icon: Brain,
      title: 'AI Integration',
      description: 'Seamlessly integrated artificial intelligence systems that learn, adapt, and optimize your experience in real-time.',
      gradient: 'from-green-500/20 to-lime-500/20',
    },
    {
      icon: Atom,
      title: 'Advanced Quantum Systems',
      description: 'Harness the power of quantum computing with our state-of-the-art quantum processing infrastructure.',
      gradient: 'from-lime-500/20 to-neon-green/20',
    },
    {
      icon: Lock,
      title: 'Encrypted Member Dashboard',
      description: 'Your personal command center with end-to-end encryption, real-time analytics, and secure communication channels.',
      gradient: 'from-neon-green/20 to-emerald-500/20',
    },
  ];

  return (
    <section
      ref={sectionRef}
      id="features"
      className="relative py-24 sm:py-32 overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0 grid-bg opacity-20" />
      <div className="absolute top-1/2 right-0 w-[500px] h-[500px] bg-neon-green/5 rounded-full blur-[150px] -translate-y-1/2" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div
          className={`text-center mb-16 transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass mb-6">
            <span className="w-2 h-2 rounded-full bg-neon-green animate-pulse" />
            <span className="text-xs font-medium text-neon-green tracking-wider uppercase">
              Core Features
            </span>
          </div>
          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-4">
            Built for the <span className="gradient-text">Future</span>
          </h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            Experience the next generation of intelligent investing with our cutting-edge 
            investment solutions designed for growth, security, performance, and long-term financial success.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <div
              key={index}
              className={`group relative p-6 rounded-2xl glass hover-lift transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
              }`}
              style={{ transitionDelay: `${index * 100 + 200}ms` }}
            >
              {/* Gradient Background on Hover */}
              <div
                className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-100 transition-opacity duration-500`}
              />

              {/* Content */}
              <div className="relative z-10">
                {/* Icon */}
                <div className="w-14 h-14 rounded-xl bg-neon-green/10 flex items-center justify-center mb-5 group-hover:bg-neon-green/20 group-hover:shadow-neon-sm transition-all duration-300">
                  <feature.icon className="w-7 h-7 text-neon-green group-hover:scale-110 transition-transform duration-300" />
                </div>

                {/* Title */}
                <h3 className="text-xl font-semibold text-white mb-3 group-hover:text-neon-green transition-colors duration-300">
                  {feature.title}
                </h3>

                {/* Description */}
                <p className="text-gray-400 text-sm leading-relaxed group-hover:text-gray-300 transition-colors duration-300">
                  {feature.description}
                </p>

                {/* Hover Indicator */}
                <div className="mt-5 flex items-center gap-2 text-neon-green opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <span className="text-sm font-medium">Learn more</span>
                  <svg
                    className="w-4 h-4 group-hover:translate-x-1 transition-transform"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 5l7 7-7 7"
                    />
                  </svg>
                </div>
              </div>

              {/* Corner Glow */}
              <div className="absolute -top-1 -right-1 w-20 h-20 bg-neon-green/10 rounded-full blur-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            </div>
          ))}
        </div>

        {/* Bottom Stats Bar */}
        <div
          className={`mt-16 p-8 rounded-2xl glass transition-all duration-700 delay-500 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { label: 'Quantum Bits', value: '1,024+' },
              { label: 'Processing Power', value: '100 PFLOPS' },
              { label: 'Encryption Level', value: 'AES-256' },
              { label: 'Response Time', value: '<1ms' },
            ].map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-2xl sm:text-3xl font-bold gradient-text text-glow mb-1">
                  {stat.value}
                </div>
                <div className="text-sm text-gray-500">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;
