import { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Eye, EyeOff, LogIn, UserPlus, KeyRound } from 'lucide-react';

const Login = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    // Simulate login
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsLoading(false);
  };

  return (
    <section
      ref={sectionRef}
      id="login"
      className="relative py-24 sm:py-32 overflow-hidden"
    >
      {/* Background Effects */}
      <div className="absolute inset-0 grid-bg opacity-20" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-neon-green/5 rounded-full blur-[200px]" />

      <div className="relative z-10 max-w-md mx-auto px-4 sm:px-6">
        {/* Login Card */}
        <div
          className={`relative transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          {/* Glowing Border Effect */}
          <div className="absolute -inset-px bg-gradient-to-r from-neon-green/30 via-neon-green/10 to-neon-green/30 rounded-2xl blur-sm" />
          <div className="absolute -inset-px bg-gradient-to-r from-neon-green/20 via-transparent to-neon-green/20 rounded-2xl animate-pulse" />

          {/* Card Content */}
          <div className="relative p-8 sm:p-10 rounded-2xl glass-strong">
            {/* Header */}
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-neon-green/10 mb-4 shadow-neon-sm">
                <LogIn className="w-8 h-8 text-neon-green" />
              </div>
              <h2 className="text-3xl font-bold text-white mb-2">
                Welcome Back
              </h2>
              <p className="text-gray-400">
                Sign in to access your Quantum Program dashboard
              </p>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Email Field */}
              <div className="space-y-2">
                <Label htmlFor="email" className="text-gray-300 text-sm font-medium">
                  Email Address
                </Label>
                <div className="relative">
                  <Input
                    id="email"
                    type="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full h-12 pl-4 pr-4 rounded-xl bg-quantum-dark/50 border-neon-green/20 text-white placeholder:text-gray-500 focus:border-neon-green focus:ring-neon-green/20 transition-all"
                    required
                  />
                </div>
              </div>

              {/* Password Field */}
              <div className="space-y-2">
                <Label htmlFor="password" className="text-gray-300 text-sm font-medium">
                  Password
                </Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full h-12 pl-4 pr-12 rounded-xl bg-quantum-dark/50 border-neon-green/20 text-white placeholder:text-gray-500 focus:border-neon-green focus:ring-neon-green/20 transition-all"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-neon-green transition-colors"
                  >
                    {showPassword ? (
                      <EyeOff className="w-5 h-5" />
                    ) : (
                      <Eye className="w-5 h-5" />
                    )}
                  </button>
                </div>
              </div>

              {/* Forgot Password Link */}
              <div className="flex justify-end">
                <a
                  href="#"
                  className="text-sm text-neon-green hover:text-neon-green/80 transition-colors flex items-center gap-1"
                >
                  <KeyRound className="w-3 h-3" />
                  Forgot Password?
                </a>
              </div>

              {/* Login Button */}
              <Button
                type="submit"
                disabled={isLoading}
                className="w-full h-12 text-base font-semibold bg-neon-green text-quantum-darker hover:bg-neon-green/90 rounded-xl shadow-neon animate-pulse-glow btn-glow transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoading ? (
                  <span className="flex items-center gap-2">
                    <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                        fill="none"
                      />
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      />
                    </svg>
                    Signing in...
                  </span>
                ) : (
                  <span className="flex items-center gap-2">
                    <LogIn className="w-5 h-5" />
                    Login
                  </span>
                )}
              </Button>
            </form>

            {/* Divider */}
            <div className="relative my-8">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-neon-green/10" />
              </div>
              <div className="relative flex justify-center">
                <span className="px-4 text-sm text-gray-500 bg-[#0a1f0a]">
                  or
                </span>
              </div>
            </div>

            {/* Create Account Link */}
            <a
              href="#"
              className="flex items-center justify-center gap-2 w-full h-12 rounded-xl border border-neon-green/30 text-neon-green font-medium hover:bg-neon-green/10 hover:border-neon-green/50 transition-all duration-300"
            >
              <UserPlus className="w-5 h-5" />
              Create Account
            </a>

            {/* Security Note */}
            <div className="mt-6 flex items-center justify-center gap-2 text-xs text-gray-500">
              <div className="w-2 h-2 rounded-full bg-neon-green animate-pulse" />
              Secured with 256-bit encryption
            </div>
          </div>
        </div>

        {/* Decorative Elements */}
        <div className="absolute -top-10 -left-10 w-20 h-20 border border-neon-green/20 rounded-full animate-spin-slow opacity-30" />
        <div className="absolute -bottom-10 -right-10 w-16 h-16 border border-neon-green/20 rounded-full animate-spin-slow opacity-30" style={{ animationDirection: 'reverse' }} />
      </div>
    </section>
  );
};

export default Login;
