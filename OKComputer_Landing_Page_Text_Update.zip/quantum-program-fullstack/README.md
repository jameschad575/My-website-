# Quantum Program - Full Stack Authentication & Dashboard System

A complete, production-ready authentication-based platform with a protected investment dashboard. Built with React, Node.js, Express, and MongoDB.

## Features

### Authentication System
- **Registration** with full validation (Full Name, Email, Phone, DOB, Password)
- **Login** with "Remember Me" functionality
- **Forgot/Reset Password** with email token (30 min expiry)
- **Password Hashing** with bcrypt (12 salt rounds)
- **JWT Token** authentication
- **Protected Routes** middleware

### Dashboard Features
- **Portfolio Overview** - Total Balance, Profit/Loss, Growth %, Available Balance
- **Performance Chart** - Interactive Recharts visualization
- **Active Investments** - Table with ROI tracking
- **Recent Transactions** - Deposit/Withdrawal/Investment history
- **Quick Actions** - Deposit, Withdraw, Invest, Transfer
- **Notifications** - Real-time alerts system
- **Account & Security** - Profile edit, Change password, 2FA toggle
- **Referral Program** - Unique referral links, bonus tracking
- **Support & Help** - Ticket submission, FAQ

## Tech Stack

### Backend
- Node.js + Express
- MongoDB + Mongoose
- JWT Authentication
- bcryptjs for password hashing
- express-validator for validation
- nodemailer for emails
- CORS enabled

### Frontend
- React 18 + TypeScript
- Vite for build tool
- Tailwind CSS + shadcn/ui components
- React Router DOM
- Axios for API calls
- Recharts for charts
- React Hook Form
- Sonner for toast notifications

## Project Structure

```
quantum-program-fullstack/
├── backend/
│   ├── models/
│   │   └── User.js
│   ├── middleware/
│   │   └── auth.js
│   ├── routes/
│   │   ├── auth.js
│   │   └── dashboard.js
│   ├── .env
│   ├── package.json
│   └── server.js
└── frontend/
    ├── src/
    │   ├── components/
    │   │   ├── auth/
    │   │   │   └── ProtectedRoute.tsx
    │   │   └── ui/
    │   ├── contexts/
    │   │   └── AuthContext.tsx
    │   ├── dashboard/
    │   │   ├── DashboardLayout.tsx
    │   │   ├── DashboardOverview.tsx
    │   │   ├── Investments.tsx
    │   │   ├── Wallet.tsx
    │   │   ├── Referrals.tsx
    │   │   ├── Notifications.tsx
    │   │   ├── Settings.tsx
    │   │   └── Support.tsx
    │   ├── pages/
    │   │   ├── Login.tsx
    │   │   ├── Register.tsx
    │   │   ├── ForgotPassword.tsx
    │   │   └── ResetPassword.tsx
    │   ├── sections/
    │   │   ├── Navigation.tsx
    │   │   ├── Hero.tsx
    │   │   ├── About.tsx
    │   │   └── Features.tsx
    │   ├── services/
    │   │   └── api.ts
    │   ├── types/
    │   │   └── index.ts
    │   ├── App.tsx
    │   ├── index.css
    │   └── main.tsx
    ├── .env
    ├── package.json
    ├── tailwind.config.js
    ├── tsconfig.json
    └── vite.config.ts
```

## Setup Instructions

### Prerequisites
- Node.js 18+
- MongoDB installed and running

### Backend Setup

1. Navigate to backend directory:
```bash
cd backend
```

2. Install dependencies:
```bash
npm install
```

3. Configure environment variables in `.env`:
```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/quantum_program
JWT_SECRET=your_super_secret_jwt_key
JWT_EXPIRE=7d
RESET_TOKEN_EXPIRE=1800000
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your_email@gmail.com
SMTP_PASS=your_app_password
FRONTEND_URL=http://localhost:5173
```

4. Start the server:
```bash
npm start
# or
npm run dev
```

### Frontend Setup

1. Navigate to frontend directory:
```bash
cd frontend
```

2. Install dependencies:
```bash
npm install
```

3. Configure environment variables in `.env`:
```env
VITE_API_URL=http://localhost:5000/api
```

4. Start the development server:
```bash
npm run dev
```

5. Build for production:
```bash
npm run build
```

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `POST /api/auth/logout` - Logout user
- `GET /api/auth/me` - Get current user
- `POST /api/auth/forgot-password` - Send reset email
- `POST /api/auth/reset-password/:token` - Reset password
- `PUT /api/auth/change-password` - Change password

### Dashboard
- `GET /api/dashboard/portfolio` - Get portfolio overview
- `GET /api/dashboard/chart` - Get chart data
- `GET /api/dashboard/investments` - Get investments
- `GET /api/dashboard/transactions` - Get transactions
- `GET /api/dashboard/notifications` - Get notifications
- `GET /api/dashboard/referral` - Get referral info
- `PUT /api/dashboard/profile` - Update profile
- `POST /api/dashboard/support-ticket` - Submit support ticket
- `POST /api/dashboard/quick-action` - Quick actions

## Security Features

- Password hashing with bcrypt (12 salt rounds)
- JWT token authentication
- Protected routes middleware
- Input validation with express-validator
- CORS configuration
- HTTP-only cookies
- Password strength requirements
- Token expiration for password reset

## License

MIT
