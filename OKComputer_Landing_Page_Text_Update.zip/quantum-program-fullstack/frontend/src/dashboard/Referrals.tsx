import React, { useEffect, useState } from 'react';
import { dashboardAPI } from '@/services/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import {
  Users,
  Copy,
  Share2,
  Gift,
  TrendingUp,
  DollarSign,
  UserPlus,
  CheckCircle,
  Facebook,
  Twitter,
  Linkedin,
  Mail,
} from 'lucide-react';
import { toast } from 'sonner';

const Referrals: React.FC = () => {
  const [referralData, setReferralData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchReferralData();
  }, []);

  const fetchReferralData = async () => {
    try {
      const response = await dashboardAPI.getReferral();
      setReferralData(response.data.data);
    } catch (error) {
      toast.error('Failed to load referral data');
    } finally {
      setIsLoading(false);
    }
  };

  const copyReferralLink = () => {
    if (referralData?.referralUrl) {
      navigator.clipboard.writeText(referralData.referralUrl);
      toast.success('Referral link copied to clipboard!');
    }
  };

  const copyReferralCode = () => {
    if (referralData?.referralCode) {
      navigator.clipboard.writeText(referralData.referralCode);
      toast.success('Referral code copied to clipboard!');
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="w-10 h-10 border-2 border-neon-green/30 border-t-neon-green rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-white">Referral Program</h1>

      {/* Hero Stats */}
      <div className="grid sm:grid-cols-3 gap-4">
        <Card className="glass border-neon-green/10">
          <CardContent className="p-6 text-center">
            <div className="w-14 h-14 rounded-xl bg-neon-green/10 flex items-center justify-center mx-auto mb-4">
              <Users className="w-7 h-7 text-neon-green" />
            </div>
            <p className="text-4xl font-bold text-white">{referralData?.referralCount || 0}</p>
            <p className="text-gray-400 mt-1">Total Referrals</p>
          </CardContent>
        </Card>
        <Card className="glass border-neon-green/10">
          <CardContent className="p-6 text-center">
            <div className="w-14 h-14 rounded-xl bg-neon-green/10 flex items-center justify-center mx-auto mb-4">
              <DollarSign className="w-7 h-7 text-neon-green" />
            </div>
            <p className="text-4xl font-bold text-neon-green">
              {formatCurrency(referralData?.referralEarnings || 0)}
            </p>
            <p className="text-gray-400 mt-1">Total Earnings</p>
          </CardContent>
        </Card>
        <Card className="glass border-neon-green/10">
          <CardContent className="p-6 text-center">
            <div className="w-14 h-14 rounded-xl bg-neon-green/10 flex items-center justify-center mx-auto mb-4">
              <Gift className="w-7 h-7 text-neon-green" />
            </div>
            <p className="text-4xl font-bold text-white">$50</p>
            <p className="text-gray-400 mt-1">Per Referral</p>
          </CardContent>
        </Card>
      </div>

      {/* Referral Link Section */}
      <Card className="glass border-neon-green/10 bg-gradient-to-br from-neon-green/5 to-transparent">
        <CardContent className="p-8">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-white mb-2">Share Your Link</h2>
            <p className="text-gray-400">Invite friends and earn $50 for each successful referral</p>
          </div>

          {/* Referral Link */}
          <div className="flex flex-col sm:flex-row gap-3 max-w-2xl mx-auto mb-6">
            <Input
              value={referralData?.referralUrl || ''}
              readOnly
              className="flex-1 bg-quantum-dark/50 border-neon-green/20 text-white h-12"
            />
            <Button
              onClick={copyReferralLink}
              className="h-12 px-6 bg-neon-green text-quantum-darker hover:bg-neon-green/90"
            >
              <Copy className="w-4 h-4 mr-2" />
              Copy Link
            </Button>
          </div>

          {/* Referral Code */}
          <div className="flex items-center justify-center gap-3 mb-8">
            <span className="text-gray-400">Your Code:</span>
            <code className="px-4 py-2 rounded-lg bg-white/5 border border-neon-green/20 text-neon-green font-mono">
              {referralData?.referralCode}
            </code>
            <button
              onClick={copyReferralCode}
              className="text-gray-400 hover:text-neon-green transition-colors"
            >
              <Copy className="w-4 h-4" />
            </button>
          </div>

          {/* Social Share */}
          <div className="flex justify-center gap-4">
            <Button variant="outline" className="w-12 h-12 rounded-full border-blue-500/30 text-blue-500 hover:bg-blue-500/10 p-0">
              <Facebook className="w-5 h-5" />
            </Button>
            <Button variant="outline" className="w-12 h-12 rounded-full border-sky-500/30 text-sky-500 hover:bg-sky-500/10 p-0">
              <Twitter className="w-5 h-5" />
            </Button>
            <Button variant="outline" className="w-12 h-12 rounded-full border-blue-600/30 text-blue-600 hover:bg-blue-600/10 p-0">
              <Linkedin className="w-5 h-5" />
            </Button>
            <Button variant="outline" className="w-12 h-12 rounded-full border-red-500/30 text-red-500 hover:bg-red-500/10 p-0">
              <Mail className="w-5 h-5" />
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* How It Works */}
      <Card className="glass border-neon-green/10">
        <CardHeader>
          <CardTitle className="text-white">How It Works</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid sm:grid-cols-3 gap-6">
            {[
              {
                icon: Share2,
                title: 'Share Your Link',
                description: 'Share your unique referral link with friends and family',
              },
              {
                icon: UserPlus,
                title: 'They Sign Up',
                description: 'Your friends create an account using your referral code',
              },
              {
                icon: Gift,
                title: 'You Both Earn',
                description: 'Earn $50 when they make their first investment',
              },
            ].map((step, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 rounded-xl bg-neon-green/10 flex items-center justify-center mx-auto mb-4">
                  <step.icon className="w-8 h-8 text-neon-green" />
                </div>
                <h3 className="text-white font-semibold mb-2">{step.title}</h3>
                <p className="text-gray-400 text-sm">{step.description}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Progress to Next Tier */}
      <Card className="glass border-neon-green/10">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-white font-semibold">Referral Progress</h3>
              <p className="text-gray-400 text-sm">Reach 10 referrals for VIP status</p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-neon-green">{referralData?.referralCount || 0}/10</p>
            </div>
          </div>
          <Progress 
            value={((referralData?.referralCount || 0) / 10) * 100} 
            className="h-3 bg-white/10"
          />
          <div className="flex items-center gap-2 mt-4 text-sm">
            <CheckCircle className="w-4 h-4 text-neon-green" />
            <span className="text-gray-400">
              {10 - (referralData?.referralCount || 0)} more referrals to unlock VIP benefits
            </span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Referrals;
