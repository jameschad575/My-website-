import React, { useEffect, useState } from 'react';
import { dashboardAPI } from '@/services/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  Briefcase,
  TrendingUp,
  TrendingDown,
  Plus,
  Calendar,
  DollarSign,
  ArrowUpRight,
} from 'lucide-react';
import { toast } from 'sonner';
import type { Investment } from '@/types';

const Investments: React.FC = () => {
  const [investments, setInvestments] = useState<Investment[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchInvestments();
  }, []);

  const fetchInvestments = async () => {
    try {
      const response = await dashboardAPI.getInvestments();
      setInvestments(response.data.data);
    } catch (error) {
      toast.error('Failed to load investments');
    } finally {
      setIsLoading(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  const activeInvestments = investments.filter(i => i.status === 'Active');
  const completedInvestments = investments.filter(i => i.status === 'Completed');
  const totalInvested = investments.reduce((sum, i) => sum + i.amount, 0);
  const totalROI = investments.reduce((sum, i) => sum + (i.amount * i.roi / 100), 0);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="w-10 h-10 border-2 border-neon-green/30 border-t-neon-green rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-white">My Investments</h1>
        <Button className="bg-neon-green text-quantum-darker hover:bg-neon-green/90">
          <Plus className="w-4 h-4 mr-2" />
          New Investment
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid sm:grid-cols-4 gap-4">
        <Card className="glass border-neon-green/10">
          <CardContent className="p-6">
            <p className="text-gray-400 text-sm">Total Invested</p>
            <p className="text-2xl font-bold text-white mt-1">{formatCurrency(totalInvested)}</p>
          </CardContent>
        </Card>
        <Card className="glass border-neon-green/10">
          <CardContent className="p-6">
            <p className="text-gray-400 text-sm">Total Returns</p>
            <p className="text-2xl font-bold text-neon-green mt-1">+{formatCurrency(totalROI)}</p>
          </CardContent>
        </Card>
        <Card className="glass border-neon-green/10">
          <CardContent className="p-6">
            <p className="text-gray-400 text-sm">Active Investments</p>
            <p className="text-2xl font-bold text-white mt-1">{activeInvestments.length}</p>
          </CardContent>
        </Card>
        <Card className="glass border-neon-green/10">
          <CardContent className="p-6">
            <p className="text-gray-400 text-sm">Completed</p>
            <p className="text-2xl font-bold text-white mt-1">{completedInvestments.length}</p>
          </CardContent>
        </Card>
      </div>

      {/* Active Investments */}
      <Card className="glass border-neon-green/10">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-neon-green" />
            Active Investments
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-gray-400 text-sm border-b border-neon-green/10">
                  <th className="text-left py-3">Investment Name</th>
                  <th className="text-right py-3">Amount</th>
                  <th className="text-right py-3">ROI</th>
                  <th className="text-center py-3">Status</th>
                  <th className="text-right py-3">Start Date</th>
                </tr>
              </thead>
              <tbody>
                {activeInvestments.map((investment) => (
                  <tr key={investment.id} className="border-b border-neon-green/5 hover:bg-white/5">
                    <td className="py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-neon-green/10 flex items-center justify-center">
                          <Briefcase className="w-5 h-5 text-neon-green" />
                        </div>
                        <div>
                          <p className="text-white font-medium">{investment.name}</p>
                          <p className="text-gray-500 text-xs">Investment ID: #{investment.id}</p>
                        </div>
                      </div>
                    </td>
                    <td className="text-right py-4 text-white font-medium">
                      {formatCurrency(investment.amount)}
                    </td>
                    <td className="text-right py-4">
                      <span className="text-neon-green flex items-center justify-end gap-1">
                        <TrendingUp className="w-4 h-4" />
                        +{investment.roi}%
                      </span>
                    </td>
                    <td className="text-center py-4">
                      <Badge className="bg-neon-green/20 text-neon-green border-neon-green/30">
                        {investment.status}
                      </Badge>
                    </td>
                    <td className="text-right py-4 text-gray-400">
                      {formatDate(investment.startDate)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Completed Investments */}
      {completedInvestments.length > 0 && (
        <Card className="glass border-neon-green/10">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <ArrowUpRight className="w-5 h-5 text-gray-400" />
              Completed Investments
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-gray-400 text-sm border-b border-neon-green/10">
                    <th className="text-left py-3">Investment Name</th>
                    <th className="text-right py-3">Amount</th>
                    <th className="text-right py-3">ROI</th>
                    <th className="text-center py-3">Status</th>
                    <th className="text-right py-3">Completed</th>
                  </tr>
                </thead>
                <tbody>
                  {completedInvestments.map((investment) => (
                    <tr key={investment.id} className="border-b border-neon-green/5 hover:bg-white/5">
                      <td className="py-4">
                        <p className="text-white font-medium">{investment.name}</p>
                      </td>
                      <td className="text-right py-4 text-white">
                        {formatCurrency(investment.amount)}
                      </td>
                      <td className="text-right py-4 text-neon-green">
                        +{investment.roi}%
                      </td>
                      <td className="text-center py-4">
                        <Badge className="bg-gray-500/20 text-gray-400 border-gray-500/30">
                          {investment.status}
                        </Badge>
                      </td>
                      <td className="text-right py-4 text-gray-400">
                        {investment.endDate ? formatDate(investment.endDate) : 'N/A'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default Investments;
