import React, { useState } from 'react';
import { dashboardAPI } from '@/services/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  HelpCircle,
  MessageSquare,
  FileQuestion,
  Send,
  CheckCircle,
  Mail,
  Phone,
  Clock,
} from 'lucide-react';
import { toast } from 'sonner';

const Support: React.FC = () => {
  const [ticketData, setTicketData] = useState({
    subject: '',
    category: '',
    message: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const faqs = [
    {
      question: 'How do I make my first investment?',
      answer: 'Navigate to the Dashboard and click on "Invest Now" in the Quick Actions panel. Select an investment option and follow the prompts.',
    },
    {
      question: 'What is the minimum investment amount?',
      answer: 'The minimum investment amount varies by fund. Most funds start at $1,000, with some premium options requiring $10,000 or more.',
    },
    {
      question: 'How long does it take to withdraw funds?',
      answer: 'Withdrawal requests are processed within 1-3 business days. The funds will appear in your linked bank account within 3-5 business days.',
    },
    {
      question: 'Is my investment secure?',
      answer: 'Yes, we use bank-level encryption and security measures. All investments are backed by real assets and insured where applicable.',
    },
    {
      question: 'How does the referral program work?',
      answer: 'Share your unique referral link with friends. When they sign up and make their first investment, you earn $50 in bonus credits.',
    },
  ];

  const handleSubmitTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!ticketData.subject || !ticketData.category || !ticketData.message) {
      toast.error('Please fill in all fields');
      return;
    }

    try {
      setIsSubmitting(true);
      await dashboardAPI.submitSupportTicket(ticketData);
      setIsSubmitted(true);
      toast.success('Support ticket submitted successfully');
    } catch (error: any) {
      toast.error(error.message || 'Failed to submit ticket');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold text-white mb-6">Support & Help</h1>

      {/* Contact Info Cards */}
      <div className="grid sm:grid-cols-3 gap-4">
        <Card className="glass border-neon-green/10">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 rounded-xl bg-neon-green/10 flex items-center justify-center mx-auto mb-4">
              <Mail className="w-6 h-6 text-neon-green" />
            </div>
            <h3 className="text-white font-semibold mb-1">Email Support</h3>
            <p className="text-gray-400 text-sm">support@quantumprogram.com</p>
          </CardContent>
        </Card>
        <Card className="glass border-neon-green/10">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 rounded-xl bg-neon-green/10 flex items-center justify-center mx-auto mb-4">
              <Phone className="w-6 h-6 text-neon-green" />
            </div>
            <h3 className="text-white font-semibold mb-1">Phone Support</h3>
            <p className="text-gray-400 text-sm">+1 (800) 123-4567</p>
          </CardContent>
        </Card>
        <Card className="glass border-neon-green/10">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 rounded-xl bg-neon-green/10 flex items-center justify-center mx-auto mb-4">
              <Clock className="w-6 h-6 text-neon-green" />
            </div>
            <h3 className="text-white font-semibold mb-1">Support Hours</h3>
            <p className="text-gray-400 text-sm">24/7 Available</p>
          </CardContent>
        </Card>
      </div>

      {/* Submit Ticket Form */}
      <Card className="glass border-neon-green/10">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-neon-green" />
            Submit a Support Ticket
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!isSubmitted ? (
            <form onSubmit={handleSubmitTicket} className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-gray-300">Subject</Label>
                  <Input
                    value={ticketData.subject}
                    onChange={(e) => setTicketData({ ...ticketData, subject: e.target.value })}
                    placeholder="Brief description of your issue"
                    className="bg-quantum-dark/50 border-neon-green/20 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-gray-300">Category</Label>
                  <Select
                    value={ticketData.category}
                    onValueChange={(value) => setTicketData({ ...ticketData, category: value })}
                  >
                    <SelectTrigger className="bg-quantum-dark/50 border-neon-green/20 text-white">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent className="bg-quantum-dark border-neon-green/20">
                      <SelectItem value="general">General Inquiry</SelectItem>
                      <SelectItem value="technical">Technical Issue</SelectItem>
                      <SelectItem value="billing">Billing & Payments</SelectItem>
                      <SelectItem value="investment">Investment Question</SelectItem>
                      <SelectItem value="security">Security Concern</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label className="text-gray-300">Message</Label>
                <Textarea
                  value={ticketData.message}
                  onChange={(e) => setTicketData({ ...ticketData, message: e.target.value })}
                  placeholder="Please describe your issue in detail..."
                  rows={5}
                  className="bg-quantum-dark/50 border-neon-green/20 text-white resize-none"
                />
              </div>
              <Button
                type="submit"
                disabled={isSubmitting}
                className="bg-neon-green text-quantum-darker hover:bg-neon-green/90"
              >
                <Send className="w-4 h-4 mr-2" />
                {isSubmitting ? 'Submitting...' : 'Submit Ticket'}
              </Button>
            </form>
          ) : (
            <div className="text-center py-8">
              <div className="w-16 h-16 rounded-full bg-neon-green/20 flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-neon-green" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Ticket Submitted!</h3>
              <p className="text-gray-400 mb-4">
                We've received your support request. Our team will respond within 24 hours.
              </p>
              <Button
                onClick={() => {
                  setIsSubmitted(false);
                  setTicketData({ subject: '', category: '', message: '' });
                }}
                variant="outline"
                className="border-neon-green/30 text-neon-green hover:bg-neon-green/10"
              >
                Submit Another Ticket
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* FAQ Section */}
      <Card className="glass border-neon-green/10">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <FileQuestion className="w-5 h-5 text-neon-green" />
            Frequently Asked Questions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div key={index} className="border-b border-neon-green/10 last:border-0 pb-4 last:pb-0">
                <h4 className="text-white font-medium mb-2 flex items-center gap-2">
                  <HelpCircle className="w-4 h-4 text-neon-green" />
                  {faq.question}
                </h4>
                <p className="text-gray-400 text-sm pl-6">{faq.answer}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Support;
