import React, { useEffect, useState } from 'react';
import { dashboardAPI } from '@/services/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Bell,
  TrendingUp,
  Shield,
  Users,
  CheckCircle,
  AlertCircle,
  Info,
  Trash2,
  CheckCheck,
} from 'lucide-react';
import { toast } from 'sonner';
import type { Notification } from '@/types';

const Notifications: React.FC = () => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchNotifications();
  }, []);

  const fetchNotifications = async () => {
    try {
      const response = await dashboardAPI.getNotifications();
      setNotifications(response.data.data.notifications);
      setUnreadCount(response.data.data.unreadCount);
    } catch (error) {
      toast.error('Failed to load notifications');
    } finally {
      setIsLoading(false);
    }
  };

  const markAllAsRead = () => {
    setNotifications(notifications.map(n => ({ ...n, read: true })));
    setUnreadCount(0);
    toast.success('All notifications marked as read');
  };

  const clearAll = () => {
    setNotifications([]);
    setUnreadCount(0);
    toast.success('All notifications cleared');
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'profit':
        return <TrendingUp className="w-5 h-5 text-neon-green" />;
      case 'security':
        return <Shield className="w-5 h-5 text-red-500" />;
      case 'referral':
        return <Users className="w-5 h-5 text-blue-500" />;
      default:
        return <Info className="w-5 h-5 text-yellow-500" />;
    }
  };

  const getBgColor = (type: string) => {
    switch (type) {
      case 'profit':
        return 'bg-neon-green/10';
      case 'security':
        return 'bg-red-500/10';
      case 'referral':
        return 'bg-blue-500/10';
      default:
        return 'bg-yellow-500/10';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor(diff / (1000 * 60));

    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days < 7) return `${days}d ago`;
    return date.toLocaleDateString();
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="w-10 h-10 border-2 border-neon-green/30 border-t-neon-green rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h1 className="text-3xl font-bold text-white">Notifications</h1>
          {unreadCount > 0 && (
            <Badge className="bg-neon-green text-quantum-darker">
              {unreadCount} new
            </Badge>
          )}
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={markAllAsRead}
            className="border-neon-green/30 text-neon-green hover:bg-neon-green/10"
          >
            <CheckCheck className="w-4 h-4 mr-2" />
            Mark All Read
          </Button>
          <Button
            variant="outline"
            onClick={clearAll}
            className="border-red-500/30 text-red-500 hover:bg-red-500/10"
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Clear All
          </Button>
        </div>
      </div>

      <Tabs defaultValue="all">
        <TabsList className="glass border-neon-green/10">
          <TabsTrigger value="all" className="data-[state=active]:bg-neon-green/20 data-[state=active]:text-neon-green">
            All ({notifications.length})
          </TabsTrigger>
          <TabsTrigger value="unread" className="data-[state=active]:bg-neon-green/20 data-[state=active]:text-neon-green">
            Unread ({unreadCount})
          </TabsTrigger>
          <TabsTrigger value="investment" className="data-[state=active]:bg-neon-green/20 data-[state=active]:text-neon-green">
            Investment
          </TabsTrigger>
          <TabsTrigger value="security" className="data-[state=active]:bg-neon-green/20 data-[state=active]:text-neon-green">
            Security
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-4">
          <NotificationList 
            notifications={notifications} 
            getIcon={getIcon} 
            getBgColor={getBgColor} 
            formatDate={formatDate} 
          />
        </TabsContent>

        <TabsContent value="unread" className="mt-4">
          <NotificationList 
            notifications={notifications.filter(n => !n.read)} 
            getIcon={getIcon} 
            getBgColor={getBgColor} 
            formatDate={formatDate} 
          />
        </TabsContent>

        <TabsContent value="investment" className="mt-4">
          <NotificationList 
            notifications={notifications.filter(n => n.type === 'investment' || n.type === 'profit')} 
            getIcon={getIcon} 
            getBgColor={getBgColor} 
            formatDate={formatDate} 
          />
        </TabsContent>

        <TabsContent value="security" className="mt-4">
          <NotificationList 
            notifications={notifications.filter(n => n.type === 'security')} 
            getIcon={getIcon} 
            getBgColor={getBgColor} 
            formatDate={formatDate} 
          />
        </TabsContent>
      </Tabs>
    </div>
  );
};

interface NotificationListProps {
  notifications: Notification[];
  getIcon: (type: string) => React.ReactNode;
  getBgColor: (type: string) => string;
  formatDate: (dateString: string) => string;
}

const NotificationList: React.FC<NotificationListProps> = ({ 
  notifications, 
  getIcon, 
  getBgColor, 
  formatDate 
}) => {
  if (notifications.length === 0) {
    return (
      <Card className="glass border-neon-green/10">
        <CardContent className="p-12 text-center">
          <div className="w-16 h-16 rounded-full bg-neon-green/10 flex items-center justify-center mx-auto mb-4">
            <Bell className="w-8 h-8 text-neon-green" />
          </div>
          <h3 className="text-xl font-semibold text-white mb-2">No notifications</h3>
          <p className="text-gray-400">You're all caught up!</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-3">
      {notifications.map((notification) => (
        <Card 
          key={notification.id} 
          className={`glass border-neon-green/10 ${!notification.read ? 'bg-neon-green/5' : ''}`}
        >
          <CardContent className="p-4">
            <div className="flex items-start gap-4">
              <div className={`w-10 h-10 rounded-lg ${getBgColor(notification.type)} flex items-center justify-center flex-shrink-0`}>
                {getIcon(notification.type)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h4 className="text-white font-medium">{notification.title}</h4>
                    <p className="text-gray-400 text-sm mt-1">{notification.message}</p>
                  </div>
                  {!notification.read && (
                    <div className="w-2 h-2 rounded-full bg-neon-green flex-shrink-0 mt-2" />
                  )}
                </div>
                <p className="text-gray-500 text-xs mt-2">{formatDate(notification.date)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default Notifications;
