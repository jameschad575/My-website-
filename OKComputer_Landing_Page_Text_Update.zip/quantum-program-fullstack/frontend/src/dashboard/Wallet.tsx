import React, { useEffect, useState } from 'react';
import { dashboardAPI } from '@/services/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Wallet as WalletIcon,
  ArrowDownLeft,
  ArrowUpRight,
  Plus,
  Minus,
  History,
  CreditCard,
  Bitcoin,
  Banknote,
} from 'lucide-react';
import { toast } from 'sonner';
import type { Portfolio, Transaction } from '@/types';

const Wallet: React.FC = () => {
  const [portfolio, setPortfolio] = useState<Portfolio | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchWalletData();
  }, []);

  const fetchWalletData = async () => {
    try {
      const [portfolioRes, transactionsRes] = await Promise.all([
        dashboardAPI.getPortfolio(),
        dashboardAPI.getTransactions(),
      ]);
      setPortfolio(portfolioRes.data.data);
      setTransactions(transactionsRes.data.data);
    } catch (error) {
      toast.error('Failed to load wallet data');
    } finally {
      setIsLoading(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="w-10 h-10 border-2 border-neon-green/30 border-t-neon-green rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-white">Wallet</h1>

      {/* Balance Cards */}
      <div className="grid sm:grid-cols-3 gap-4">
        <Card className="glass border-neon-green/10 bg-gradient-to-br from-neon-green/10 to-transparent">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Total Balance</p>
                <p className="text-3xl font-bold text-white mt-1">
                  {formatCurrency(portfolio?.totalBalance || 0)}
                </p>
              </div>
              <div className="w-14 h-14 rounded-xl bg-neon-green/20 flex items-center justify-center">
                <WalletIcon className="w-7 h-7 text-neon-green" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="glass border-neon-green/10">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Available</p>
                <p className="text-3xl font-bold text-white mt-1">
                  {formatCurrency(portfolio?.availableBalance || 0)}
                </p>
              </div>
              <div className="w-14 h-14 rounded-xl bg-blue-500/10 flex items-center justify-center">
                <Banknote className="w-7 h-7 text-blue-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="glass border-neon-green/10">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Invested</p>
                <p className="text-3xl font-bold text-white mt-1">
                  {formatCurrency(portfolio?.investedAmount || 0)}
                </p>
              </div>
              <div className="w-14 h-14 rounded-xl bg-purple-500/10 flex items-center justify-center">
                <Bitcoin className="w-7 h-7 text-purple-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="flex flex-wrap gap-4">
        <Button className="h-14 px-8 bg-neon-green text-quantum-darker hover:bg-neon-green/90">
          <Plus className="w-5 h-5 mr-2" />
          Deposit
        </Button>
        <Button variant="outline" className="h-14 px-8 border-neon-green/30 text-neon-green hover:bg-neon-green/10">
          <Minus className="w-5 h-5 mr-2" />
          Withdraw
        </Button>
        <Button variant="outline" className="h-14 px-8 border-blue-500/30 text-blue-500 hover:bg-blue-500/10">
          <CreditCard className="w-5 h-5 mr-2" />
          Add Card
        </Button>
      </div>

      {/* Transaction History */}
      <Card className="glass border-neon-green/10">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <History className="w-5 h-5 text-neon-green" />
            Transaction History
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all">
            <TabsList className="glass border-neon-green/10 mb-4">
              <TabsTrigger value="all" className="data-[state=active]:bg-neon-green/20 data-[state=active]:text-neon-green">All</TabsTrigger>
              <TabsTrigger value="deposits" className="data-[state=active]:bg-neon-green/20 data-[state=active]:text-neon-green">Deposits</TabsTrigger>
              <TabsTrigger value="withdrawals" className="data-[state=active]:bg-neon-green/20 data-[state=active]:text-neon-green">Withdrawals</TabsTrigger>
            </TabsList>

            <TabsContent value="all">
              <TransactionTable transactions={transactions} formatCurrency={formatCurrency} formatDate={formatDate} />
            </TabsContent>
            <TabsContent value="deposits">
              <TransactionTable 
                transactions={transactions.filter(t => t.type === 'Deposit' || t.type === 'Profit')} 
                formatCurrency={formatCurrency} 
                formatDate={formatDate} 
              />
            </TabsContent>
            <TabsContent value="withdrawals">
              <TransactionTable 
                transactions={transactions.filter(t => t.type === 'Withdrawal')} 
                formatCurrency={formatCurrency} 
                formatDate={formatDate} 
              />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

interface TransactionTableProps {
  transactions: Transaction[];
  formatCurrency: (amount: number) => string;
  formatDate: (dateString: string) => string;
}

const TransactionTable: React.FC<TransactionTableProps> = ({ transactions, formatCurrency, formatDate }) => (
  <div className="overflow-x-auto">
    <table className="w-full">
      <thead>
        <tr className="text-gray-400 text-sm border-b border-neon-green/10">
          <th className="text-left py-3">Type</th>
          <th className="text-left py-3">Description</th>
          <th className="text-right py-3">Amount</th>
          <th className="text-center py-3">Status</th>
          <th className="text-right py-3">Date</th>
        </tr>
      </thead>
      <tbody>
        {transactions.map((transaction) => (
          <tr key={transaction.id} className="border-b border-neon-green/5 hover:bg-white/5">
            <td className="py-4">
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                transaction.type === 'Deposit' || transaction.type === 'Profit' ? 'bg-neon-green/10' :
                transaction.type === 'Withdrawal' ? 'bg-red-500/10' :
                'bg-purple-500/10'
              }`}>
                {transaction.type === 'Deposit' || transaction.type === 'Profit' ? (
                  <ArrowDownLeft className="w-5 h-5 text-neon-green" />
                ) : transaction.type === 'Withdrawal' ? (
                  <ArrowUpRight className="w-5 h-5 text-red-500" />
                ) : (
                  <ArrowUpRight className="w-5 h-5 text-purple-500" />
                )}
              </div>
            </td>
            <td className="py-4">
              <p className="text-white font-medium">{transaction.description}</p>
              <p className="text-gray-500 text-sm">{transaction.type}</p>
            </td>
            <td className={`text-right py-4 font-medium ${
              transaction.amount > 0 ? 'text-neon-green' : 'text-white'
            }`}>
              {transaction.amount > 0 ? '+' : ''}{formatCurrency(transaction.amount)}
            </td>
            <td className="text-center py-4">
              <span className={`px-3 py-1 rounded-full text-xs ${
                transaction.status === 'Completed' ? 'bg-neon-green/20 text-neon-green' :
                transaction.status === 'Pending' ? 'bg-yellow-500/20 text-yellow-500' :
                'bg-red-500/20 text-red-500'
              }`}>
                {transaction.status}
              </span>
            </td>
            <td className="text-right py-4 text-gray-400">
              {formatDate(transaction.date)}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  </div>
);

export default Wallet;
