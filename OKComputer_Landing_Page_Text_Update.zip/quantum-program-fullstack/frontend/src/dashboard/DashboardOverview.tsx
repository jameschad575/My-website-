import React, { useEffect, useState } from 'react';
import { dashboardAPI } from '@/services/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  TrendingUp,
  TrendingDown,
  Wallet,
  PiggyBank,
  DollarSign,
  ArrowUpRight,
  ArrowDownRight,
  Clock,
  CheckCircle,
  AlertCircle,
  Bell,
  Users,
  Copy,
  Plus,
  Minus,
  Send,
  Briefcase,
} from 'lucide-react';
import { toast } from 'sonner';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from 'recharts';
import type { Portfolio, Investment, Transaction, Notification, ChartData } from '@/types';

const DashboardOverview: React.FC = () => {
  const [portfolio, setPortfolio] = useState<Portfolio | null>(null);
  const [investments, setInvestments] = useState<Investment[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [chartData, setChartData] = useState<ChartData | null>(null);
  const [referralData, setReferralData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      setIsLoading(true);
      const [portfolioRes, investmentsRes, transactionsRes, notificationsRes, chartRes, referralRes] = 
        await Promise.all([
          dashboardAPI.getPortfolio(),
          dashboardAPI.getInvestments(),
          dashboardAPI.getTransactions(),
          dashboardAPI.getNotifications(),
          dashboardAPI.getChartData(),
          dashboardAPI.getReferral(),
        ]);

      setPortfolio(portfolioRes.data.data);
      setInvestments(investmentsRes.data.data);
      setTransactions(transactionsRes.data.data);
      setNotifications(notificationsRes.data.data.notifications);
      setChartData(chartRes.data.data);
      setReferralData(referralRes.data.data);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      toast.error('Failed to load dashboard data');
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickAction = async (action: string) => {
    toast.info(`${action} feature coming soon!`);
  };

  const copyReferralLink = () => {
    if (referralData?.referralUrl) {
      navigator.clipboard.writeText(referralData.referralUrl);
      toast.success('Referral link copied to clipboard!');
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="flex flex-col items-center gap-4">
          <div className="w-10 h-10 border-2 border-neon-green/30 border-t-neon-green rounded-full animate-spin" />
          <p className="text-gray-400">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Portfolio Overview */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Balance */}
        <Card className="glass border-neon-green/10">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Total Balance</p>
                <p className="text-2xl font-bold text-white mt-1">
                  {formatCurrency(portfolio?.totalBalance || 0)}
                </p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-neon-green/10 flex items-center justify-center">
                <Wallet className="w-6 h-6 text-neon-green" />
              </div>
            </div>
            <div className="flex items-center gap-2 mt-4">
              <TrendingUp className="w-4 h-4 text-neon-green" />
              <span className="text-neon-green text-sm">+{portfolio?.investmentGrowth || 0}%</span>
              <span className="text-gray-500 text-sm">this month</span>
            </div>
          </CardContent>
        </Card>

        {/* Total Profit */}
        <Card className="glass border-neon-green/10">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Total Profit</p>
                <p className="text-2xl font-bold text-neon-green mt-1">
                  +{formatCurrency(portfolio?.totalProfit || 0)}
                </p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-neon-green/10 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-neon-green" />
              </div>
            </div>
            <div className="flex items-center gap-2 mt-4">
              <ArrowUpRight className="w-4 h-4 text-neon-green" />
              <span className="text-neon-green text-sm">Profitable</span>
            </div>
          </CardContent>
        </Card>

        {/* Available Balance */}
        <Card className="glass border-neon-green/10">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Available Balance</p>
                <p className="text-2xl font-bold text-white mt-1">
                  {formatCurrency(portfolio?.availableBalance || 0)}
                </p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-blue-500" />
              </div>
            </div>
            <div className="flex items-center gap-2 mt-4">
              <span className="text-gray-500 text-sm">Ready to invest</span>
            </div>
          </CardContent>
        </Card>

        {/* Invested Amount */}
        <Card className="glass border-neon-green/10">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Invested Amount</p>
                <p className="text-2xl font-bold text-white mt-1">
                  {formatCurrency(portfolio?.investedAmount || 0)}
                </p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-purple-500/10 flex items-center justify-center">
                <PiggyBank className="w-6 h-6 text-purple-500" />
              </div>
            </div>
            <div className="flex items-center gap-2 mt-4">
              <span className="text-gray-500 text-sm">Across {investments.length} investments</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { label: 'Deposit', icon: Plus, color: 'bg-neon-green', onClick: () => handleQuickAction('Deposit') },
          { label: 'Withdraw', icon: Minus, color: 'bg-orange-500', onClick: () => handleQuickAction('Withdraw') },
          { label: 'Invest Now', icon: Briefcase, color: 'bg-blue-500', onClick: () => handleQuickAction('Invest') },
          { label: 'Transfer', icon: Send, color: 'bg-purple-500', onClick: () => handleQuickAction('Transfer') },
        ].map((action, index) => (
          <Button
            key={index}
            onClick={action.onClick}
            className={`h-20 flex flex-col items-center justify-center gap-2 ${action.color}/10 hover:${action.color}/20 border-0`}
          >
            <action.icon className={`w-6 h-6 ${action.color.replace('bg-', 'text-')}`} />
            <span className={`${action.color.replace('bg-', 'text-')}`}>{action.label}</span>
          </Button>
        ))}
      </div>

      {/* Charts & Tables Row */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Performance Chart */}
        <Card className="lg:col-span-2 glass border-neon-green/10">
          <CardHeader className="pb-2">
            <CardTitle className="text-white flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-neon-green" />
              Portfolio Performance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData?.labels.map((label, i) => ({
                  name: label,
                  portfolio: chartData.datasets[0].data[i],
                  invested: chartData.datasets[1].data[i],
                }))}>
                  <defs>
                    <linearGradient id="colorPortfolio" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#39ff14" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#39ff14" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="colorInvested" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1a3a1a" />
                  <XAxis dataKey="name" stroke="#4a5568" />
                  <YAxis stroke="#4a5568" tickFormatter={(value) => `$${value / 1000}k`} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0a1f0a',
                      border: '1px solid #39ff14',
                      borderRadius: '8px',
                    }}
                    formatter={(value: number) => formatCurrency(value)}
                  />
                  <Area
                    type="monotone"
                    dataKey="portfolio"
                    stroke="#39ff14"
                    fillOpacity={1}
                    fill="url(#colorPortfolio)"
                    name="Portfolio Value"
                  />
                  <Area
                    type="monotone"
                    dataKey="invested"
                    stroke="#3b82f6"
                    fillOpacity={1}
                    fill="url(#colorInvested)"
                    name="Invested Amount"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Notifications */}
        <Card className="glass border-neon-green/10">
          <CardHeader className="pb-2">
            <CardTitle className="text-white flex items-center gap-2">
              <Bell className="w-5 h-5 text-neon-green" />
              Notifications
              <Badge className="bg-neon-green text-quantum-darker ml-auto">
                {notifications.filter(n => !n.read).length}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-80 overflow-y-auto">
              {notifications.slice(0, 5).map((notification) => (
                <div
                  key={notification.id}
                  className={`p-3 rounded-lg ${notification.read ? 'bg-white/5' : 'bg-neon-green/10'} border border-neon-green/10`}
                >
                  <div className="flex items-start gap-3">
                    <div className={`w-2 h-2 rounded-full mt-2 ${
                      notification.type === 'profit' ? 'bg-neon-green' :
                      notification.type === 'security' ? 'bg-red-500' :
                      notification.type === 'referral' ? 'bg-blue-500' :
                      'bg-yellow-500'
                    }`} />
                    <div className="flex-1">
                      <p className="text-white text-sm font-medium">{notification.title}</p>
                      <p className="text-gray-400 text-xs mt-1">{notification.message}</p>
                      <p className="text-gray-500 text-xs mt-1">{formatDate(notification.date)}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Active Investments & Transactions */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Active Investments */}
        <Card className="glass border-neon-green/10">
          <CardHeader className="pb-2">
            <CardTitle className="text-white flex items-center gap-2">
              <Briefcase className="w-5 h-5 text-neon-green" />
              Active Investments
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-gray-400 text-sm border-b border-neon-green/10">
                    <th className="text-left py-3">Investment</th>
                    <th className="text-right py-3">Amount</th>
                    <th className="text-right py-3">ROI</th>
                    <th className="text-center py-3">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {investments.slice(0, 4).map((investment) => (
                    <tr key={investment.id} className="border-b border-neon-green/5">
                      <td className="py-3">
                        <p className="text-white font-medium">{investment.name}</p>
                        <p className="text-gray-500 text-xs">{formatDate(investment.startDate)}</p>
                      </td>
                      <td className="text-right py-3 text-white">
                        {formatCurrency(investment.amount)}
                      </td>
                      <td className="text-right py-3">
                        <span className="text-neon-green">+{investment.roi}%</span>
                      </td>
                      <td className="text-center py-3">
                        <Badge
                          className={
                            investment.status === 'Active'
                              ? 'bg-neon-green/20 text-neon-green border-neon-green/30'
                              : 'bg-gray-500/20 text-gray-400 border-gray-500/30'
                          }
                        >
                          {investment.status}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Recent Transactions */}
        <Card className="glass border-neon-green/10">
          <CardHeader className="pb-2">
            <CardTitle className="text-white flex items-center gap-2">
              <Clock className="w-5 h-5 text-neon-green" />
              Recent Transactions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-gray-400 text-sm border-b border-neon-green/10">
                    <th className="text-left py-3">Type</th>
                    <th className="text-left py-3">Description</th>
                    <th className="text-right py-3">Amount</th>
                    <th className="text-center py-3">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {transactions.slice(0, 4).map((transaction) => (
                    <tr key={transaction.id} className="border-b border-neon-green/5">
                      <td className="py-3">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                          transaction.type === 'Deposit' ? 'bg-neon-green/10' :
                          transaction.type === 'Withdrawal' ? 'bg-red-500/10' :
                          transaction.type === 'Profit' ? 'bg-blue-500/10' :
                          'bg-purple-500/10'
                        }`}>
                          {transaction.type === 'Deposit' && <ArrowDownRight className="w-4 h-4 text-neon-green" />}
                          {transaction.type === 'Withdrawal' && <ArrowUpRight className="w-4 h-4 text-red-500" />}
                          {transaction.type === 'Profit' && <TrendingUp className="w-4 h-4 text-blue-500" />}
                          {transaction.type === 'Investment' && <Briefcase className="w-4 h-4 text-purple-500" />}
                        </div>
                      </td>
                      <td className="py-3">
                        <p className="text-white text-sm">{transaction.description}</p>
                        <p className="text-gray-500 text-xs">{formatDate(transaction.date)}</p>
                      </td>
                      <td className={`text-right py-3 font-medium ${
                        transaction.amount > 0 ? 'text-neon-green' : 'text-white'
                      }`}>
                        {transaction.amount > 0 ? '+' : ''}{formatCurrency(transaction.amount)}
                      </td>
                      <td className="text-center py-3">
                        {transaction.status === 'Completed' ? (
                          <CheckCircle className="w-5 h-5 text-neon-green mx-auto" />
                        ) : transaction.status === 'Pending' ? (
                          <Clock className="w-5 h-5 text-yellow-500 mx-auto" />
                        ) : (
                          <AlertCircle className="w-5 h-5 text-red-500 mx-auto" />
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Referral Section */}
      <Card className="glass border-neon-green/10">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-xl bg-neon-green/10 flex items-center justify-center">
                <Users className="w-7 h-7 text-neon-green" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">Refer & Earn</h3>
                <p className="text-gray-400">Invite friends and earn $50 per referral</p>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white/5 border border-neon-green/20">
                <code className="text-neon-green text-sm">{referralData?.referralCode}</code>
              </div>
              <Button
                onClick={copyReferralLink}
                className="bg-neon-green text-quantum-darker hover:bg-neon-green/90"
              >
                <Copy className="w-4 h-4 mr-2" />
                Copy Link
              </Button>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 mt-6 pt-6 border-t border-neon-green/10">
            <div className="text-center">
              <p className="text-3xl font-bold text-neon-green">{referralData?.referralCount || 0}</p>
              <p className="text-gray-400 text-sm">Total Referrals</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-neon-green">{formatCurrency(referralData?.referralEarnings || 0)}</p>
              <p className="text-gray-400 text-sm">Bonus Earnings</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DashboardOverview;
