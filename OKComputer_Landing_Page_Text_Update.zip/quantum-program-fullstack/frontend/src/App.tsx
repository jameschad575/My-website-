import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'sonner';
import { AuthProvider } from '@/contexts/AuthContext';
import ProtectedRoute from '@/components/auth/ProtectedRoute';

// Landing Pages
import Navigation from './sections/Navigation';
import Hero from './sections/Hero';
import About from './sections/About';
import Features from './sections/Features';
import Footer from './sections/Footer';

// Auth Pages
import Login from './pages/Login';
import Register from './pages/Register';
import ForgotPassword from './pages/ForgotPassword';
import ResetPassword from './pages/ResetPassword';

// Dashboard Pages
import DashboardLayout from './dashboard/DashboardLayout';
import DashboardOverview from './dashboard/DashboardOverview';
import Investments from './dashboard/Investments';
import Wallet from './dashboard/Wallet';
import Referrals from './dashboard/Referrals';
import Notifications from './dashboard/Notifications';
import Settings from './dashboard/Settings';
import Support from './dashboard/Support';

// Landing Page Component
const LandingPage = () => (
  <div className="min-h-screen bg-quantum-darker text-white overflow-x-hidden">
    <Navigation />
    <main>
      <Hero />
      <About />
      <Features />
      {/* Login section removed from landing - redirect to /login */}
    </main>
    <Footer />
  </div>
);

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<LandingPage />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
          <Route path="/reset-password/:token" element={<ResetPassword />} />

          {/* Protected Dashboard Routes */}
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <DashboardLayout>
                  <DashboardOverview />
                </DashboardLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/dashboard/investments"
            element={
              <ProtectedRoute>
                <DashboardLayout>
                  <Investments />
                </DashboardLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/dashboard/wallet"
            element={
              <ProtectedRoute>
                <DashboardLayout>
                  <Wallet />
                </DashboardLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/dashboard/referrals"
            element={
              <ProtectedRoute>
                <DashboardLayout>
                  <Referrals />
                </DashboardLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/dashboard/notifications"
            element={
              <ProtectedRoute>
                <DashboardLayout>
                  <Notifications />
                </DashboardLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/dashboard/settings"
            element={
              <ProtectedRoute>
                <DashboardLayout>
                  <Settings />
                </DashboardLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/dashboard/support"
            element={
              <ProtectedRoute>
                <DashboardLayout>
                  <Support />
                </DashboardLayout>
              </ProtectedRoute>
            }
          />

          {/* Catch all - redirect to home */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Router>
      <Toaster 
        position="top-right" 
        toastOptions={{
          style: {
            background: '#0a1f0a',
            border: '1px solid #39ff14',
            color: '#fff',
          },
        }}
      />
    </AuthProvider>
  );
}

export default App;
